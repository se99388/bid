export class MatchSeq{
    public identity?: number;
    public date?: Date ;
    public alignmentMask?: string;
    public score?: number;
    public customerName?: string;
    public sequenceLength?: number;
    public seqId?: string;
}

