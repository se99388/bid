export class BidData{
    public id?: number;
    public date?: Date ;
    public rawData?: string;
    public sequence?: string;
    public folder?: string;
    public customer?: string;
    public number?: number;
    public seq_id?: string;
}