export class CountBids{
    public countAllBids?: number;
}