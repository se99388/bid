export class Customer{
    customer?: string
}