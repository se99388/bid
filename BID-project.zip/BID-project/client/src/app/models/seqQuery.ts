export class SeqQuery{
    public customer?: string;
    public seq?: string;
    public year?: number;
    public cutoff?: number;

}